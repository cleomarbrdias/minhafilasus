class WaitEstimate {
  const WaitEstimate({
    required this.minMonths,
    required this.maxMonths,
    this.minAdditionalDays = 0,
    int? maxAdditionalDays,
    int? additionalDays,
  }) : maxAdditionalDays =
           maxAdditionalDays ?? additionalDays ?? minAdditionalDays;

  final int minMonths;
  final int maxMonths;
  final int minAdditionalDays;
  final int maxAdditionalDays;

  String get label {
    final String minLabel = _fullLabel(minMonths, minAdditionalDays);
    final String maxLabel = _fullLabel(maxMonths, maxAdditionalDays);

    if (minMonths == maxMonths && minAdditionalDays == maxAdditionalDays) {
      return minLabel;
    }

    return '$minLabel a $maxLabel';
  }

  String _fullLabel(int months, int days) {
    final List<String> parts = <String>[];

    if (months > 0) {
      parts.add(_monthLabel(months));
    }

    if (days > 0) {
      parts.add(_dayLabel(days));
    }

    if (parts.isEmpty) {
      return 'menos de 1 dia';
    }

    return parts.join(' e ');
  }

  String _monthLabel(int value) => '$value mês${value > 1 ? 'es' : ''}';

  String _dayLabel(int value) => '$value dia${value > 1 ? 's' : ''}';
}
