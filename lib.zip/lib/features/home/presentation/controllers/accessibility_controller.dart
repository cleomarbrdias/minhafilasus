import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';

/// Estado global de acessibilidade do aplicativo.
///
/// Esta classe concentra preferências que afetam:
/// - leitura por voz;
/// - contraste;
/// - modo daltônico;
/// - escala global do texto.
class AccessibilityState {
  const AccessibilityState({
    required this.autoAnnounceQueuePosition,
    required this.speechRate,
    required this.highContrastEnabled,
    required this.colorBlindAssistEnabled,
    required this.textScaleFactor,
  });

  /// Estado inicial padrão do app.
  ///
  /// Decisões atuais:
  /// - autoAnnounceQueuePosition = false
  ///   Evita leitura automática sem o usuário optar por isso.
  ///
  /// - speechRate = 0.85
  ///   Valor definido como padrão porque ficou mais natural nos testes.
  ///
  /// - highContrastEnabled = false
  ///   Alto contraste desativado por padrão.
  ///
  /// - colorBlindAssistEnabled = false
  ///   Modo daltônico desativado por padrão.
  ///
  /// - textScaleFactor = 1.0
  ///   Escala de fonte padrão.
  const AccessibilityState.initial()
    : autoAnnounceQueuePosition = false,
      speechRate = 1.05,
      highContrastEnabled = false,
      colorBlindAssistEnabled = false,
      textScaleFactor = 1.0;

  /// Define se a posição da fila será anunciada automaticamente ao abrir a tela.
  final bool autoAnnounceQueuePosition;

  /// Velocidade da fala usada no TTS.
  ///
  /// Faixa adotada no projeto:
  /// - 0.45 = mais lenta
  /// - 0.85 = padrão atual
  /// - 1.65 = mais rápida
  final double speechRate;

  /// Ativa tema de alto contraste para melhorar leitura visual.
  final bool highContrastEnabled;

  /// Ativa ajustes visuais voltados a usuários com daltonismo.
  final bool colorBlindAssistEnabled;

  /// Fator de escala do texto aplicado globalmente no app.
  final double textScaleFactor;

  /// Cria uma cópia do estado atual alterando apenas os campos informados.
  AccessibilityState copyWith({
    bool? autoAnnounceQueuePosition,
    double? speechRate,
    bool? highContrastEnabled,
    bool? colorBlindAssistEnabled,
    double? textScaleFactor,
  }) {
    return AccessibilityState(
      autoAnnounceQueuePosition:
          autoAnnounceQueuePosition ?? this.autoAnnounceQueuePosition,
      speechRate: speechRate ?? this.speechRate,
      highContrastEnabled: highContrastEnabled ?? this.highContrastEnabled,
      colorBlindAssistEnabled:
          colorBlindAssistEnabled ?? this.colorBlindAssistEnabled,
      textScaleFactor: textScaleFactor ?? this.textScaleFactor,
    );
  }
}

/// Provider principal do controller de acessibilidade.
///
/// Expõe:
/// - o estado atual;
/// - os métodos para atualizar as preferências.
final accessibilityControllerProvider =
    StateNotifierProvider<AccessibilityController, AccessibilityState>((
      Ref ref,
    ) {
      return AccessibilityController();
    });

/// Controller responsável por alterar o estado de acessibilidade do app.
class AccessibilityController extends StateNotifier<AccessibilityState> {
  AccessibilityController() : super(const AccessibilityState.initial());

  /// Ativa ou desativa a leitura automática da posição da fila.
  void setAutoAnnounceQueuePosition(bool value) {
    state = state.copyWith(autoAnnounceQueuePosition: value);
  }

  /// Define a velocidade da fala do recurso TTS.
  ///
  /// Faixa atual:
  /// - mínimo: 0.45
  /// - máximo: 1.65
  ///
  /// Observação:
  /// o comportamento pode variar entre Android, iOS e desktop.
  void setSpeechRate(double value) {
    state = state.copyWith(speechRate: value.clamp(0.45, 1.65));
  }

  /// Ativa ou desativa o modo de alto contraste.
  void setHighContrastEnabled(bool value) {
    state = state.copyWith(highContrastEnabled: value);
  }

  /// Ativa ou desativa o modo de assistência para daltonismo.
  void setColorBlindAssistEnabled(bool value) {
    state = state.copyWith(colorBlindAssistEnabled: value);
  }

  /// Ajusta a escala global da fonte do app.
  ///
  /// Faixa atual:
  /// - mínimo: 1.0
  /// - máximo: 1.6
  void setTextScaleFactor(double value) {
    state = state.copyWith(textScaleFactor: value.clamp(1.0, 1.6));
  }
}
